-- phpMyAdmin SQL Dump
-- version 4.6.4
-- https://www.phpmyadmin.net/
--
-- Anamakine: 127.0.0.1
-- Üretim Zamanı: 21 Kas 2017, 12:54:35
-- Sunucu sürümü: 5.7.14
-- PHP Sürümü: 5.6.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Veritabanı: `668bebisar`
--

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `hakkimizda`
--

CREATE TABLE `hakkimizda` (
  `hakkimizda_id` int(11) NOT NULL,
  `hakkimizda_baslik` varchar(250) COLLATE utf8_swedish_ci NOT NULL,
  `hakkimizda_icerik` text COLLATE utf8_swedish_ci NOT NULL,
  `hakkimizda_video` varchar(50) COLLATE utf8_swedish_ci NOT NULL,
  `hakkimizda_vizyon` text COLLATE utf8_swedish_ci NOT NULL,
  `hakkimizda_misyon` text COLLATE utf8_swedish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_swedish_ci;

--
-- Tablo döküm verisi `hakkimizda`
--

INSERT INTO `hakkimizda` (`hakkimizda_id`, `hakkimizda_baslik`, `hakkimizda_icerik`, `hakkimizda_video`, `hakkimizda_vizyon`, `hakkimizda_misyon`) VALUES
(0, 'OM OSS  ', '<blockquote>\r\n<p>Plattformen #668bebisar &auml;r en plattform som grundats i Sverige och &auml;r en plattform f&ouml;r bebisar och barn. Syftet med plattformen &auml;r att bidra ett medvetande kring barns utsatthet i f&auml;ngelser i Turkiet och att d&auml;rmed bidra till att de f&aring;r den frihet som de har r&auml;tt till.</p>\r\n\r\n<p>Plattformen #668bebisar &auml;r en politisk och religi&ouml;st obunden plattform som &auml;r emot all typ av religi&ouml;s, etnisk, politisk eller sexuellt diskriminering.</p>\r\n</blockquote>\r\n', 'toeOHVptE_o ', 'vizyon        ', 'misyon        ');

--
-- Dökümü yapılmış tablolar için indeksler
--

--
-- Tablo için indeksler `hakkimizda`
--
ALTER TABLE `hakkimizda`
  ADD PRIMARY KEY (`hakkimizda_id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
