-- phpMyAdmin SQL Dump
-- version 4.6.4
-- https://www.phpmyadmin.net/
--
-- Anamakine: 127.0.0.1
-- Üretim Zamanı: 21 Kas 2017, 12:54:42
-- Sunucu sürümü: 5.7.14
-- PHP Sürümü: 5.6.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Veritabanı: `668bebisar`
--

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `icerik`
--

CREATE TABLE `icerik` (
  `icerik_id` int(11) NOT NULL,
  `icerik_zaman` datetime NOT NULL,
  `icerik_resimyol` varchar(250) COLLATE utf8_swedish_ci NOT NULL,
  `icerik_ad` varchar(250) COLLATE utf8_swedish_ci NOT NULL,
  `icerik_detay` text COLLATE utf8_swedish_ci NOT NULL,
  `icerik_keyword` varchar(250) COLLATE utf8_swedish_ci NOT NULL,
  `icerik_durum` varchar(1) COLLATE utf8_swedish_ci NOT NULL DEFAULT '1',
  `icerik_kaynak` varchar(300) COLLATE utf8_swedish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_swedish_ci;

--
-- Tablo döküm verisi `icerik`
--

INSERT INTO `icerik` (`icerik_id`, `icerik_zaman`, `icerik_resimyol`, `icerik_ad`, `icerik_detay`, `icerik_keyword`, `icerik_durum`, `icerik_kaynak`) VALUES
(5, '2017-11-20 14:16:43', 'img/icerik/21375281992178528201DJvtTLfU8AEdS8N.jpg', '668 barn i fängelse efter utrensningen i Turkiet', '<p>Den turkiska regeringens utrensning sl&aring;r &auml;ven mot de yngsta. 668 barn sitter just nu f&auml;ngslade med sina f&ouml;r&auml;ldrar i Turkiet.</p>\r\n\r\n<p>N&auml;r tv&aring;&aring;rige Serkan v&auml;l har h&auml;mtats plockas leksakerna snabbt fram. Inne i f&auml;ngelset &auml;r det n&auml;mligen inte till&aring;tet f&ouml;r barn att ha h&aring;rda leksaker.</p>\r\n\r\n<p>Morfar Ali Riza Tolu &auml;r kritisk till att Serkan m&aring;ste bo i f&auml;ngelset: &rdquo;Det &auml;r inte en plats f&ouml;r barn&rdquo;, s&auml;ger han.</p>\r\n\r\n<p>&nbsp;</p>\r\n', '668, bebisar, barn, fängelse, turkiet', '1', 'https://www.dn.se/nyheter/varlden/668-barn-i-fangelse-efter-utrensningen-i-turkiet/'),
(6, '2017-11-20 14:32:06', 'img/icerik/23533212872761927557babies.png', 'A Campaign Of Awareness Organised Worldwide For #668Babies In Turkish Prisons', '<p>A worldwide awareness campaign was conducted on Saturday in major cities across the world including London, Berlin and Stockholm for 668 babies who were jailed together with their mothers in Turkey under autocratic regime of Turkish President Recep Tayyip Erdoğan.</p>\r\n\r\n<p>The campaign was also supported by social media users with a call of &ldquo;Raise Your Voice For 668 Babies and 17,000 Women in Prisons&rdquo; under the hashtags in different languages including Turkish and English like #668Babies and #668BebekHapiste along the day.</p>\r\n\r\n<p>Turkish government put at least 668 babies behind the bars as their fathers and mothers were arrested and sent to jail as part of massive post-coup witch hunt campaign targeting the alleged members of the G&uuml;len movement.</p>\r\n\r\n<p>The prison facilities provided to pregnant women and the women having babies under who were imprisoned in contravention of the laws are very limited.&nbsp;Many prisons are struggling to meet the needs of babies. In&nbsp;some prisons, 20 female prisoners with 4 infants have to stay in 8-person ward. Some women lye with a baby on a blanket laid on the concrete floor.</p>\r\n\r\n<p>According to accounts of those who released from the prisons, the crib rate for babies is very low, the mother and the baby are lying together in the bunk. They need to entrust their babies to their friends in order to use the bathroom.</p>\r\n\r\n<p>Moreover, there are no additional foods such as yogurt, eggs or soup to be given to babies. There are no areas where children would crawl and play. Needs like baby cloth, wet wipes are delayed for weeks and given insufficiently. Infants who have fever or are sick can have up to one day waiting time to go to the hospital. Needs like a walker are not given. There is no additional time for babies in open visit.</p>\r\n', 'barn, fängelse, prison, 668, children, bebisar', '1', 'https://stockholmcf.org/a-campaign-of-awareness-organised-worldwide-for-668babies-in-turkish-prisons/'),
(7, '2017-11-20 17:47:22', 'img/icerik/24344302443032927442ChildrenPrison.jpg', 'Turkish Gov’t Jails 108 Babies And Children More In Past 3 Months, Bringing Total To 668', '<p>The number of babies and children aged between 0 to 6, who are being held in Turkish prisons along with their parents, rose from 560 to 668, according to the most recent data given by the Turkish government.</p>\r\n\r\n<p>As a reply to Turkey&rsquo;s main opposition Republican Peoples&rsquo; Party (CHP) deputy Gamze İlgezdi&rsquo;s question motion, Turkish Justice Ministry has stated that the number of children staying along with their mothers behind bars has hit 668 as of July 4, 2017. The corresponding number was 560 in April.</p>\r\n\r\n<p>Out of 668, 149 are aged between 0 and 12 months; 140 children are 1-year-old; 124 children are 2 years old; 117 children are 3 years old; 77 children are 4 years old; 44 children are 5 years old; 6 children are 6 years old; while age of the remaining 11 are unknown, the ministry said.</p>\r\n\r\n<p>Children are taken into prison in the absence of family members to look after them outside. Turkish government has launched a sweeping crackdown across the country, detaining more than 120,000 and jailing some 55,000 over alleged links to a controversial coup attempt on July 15, 2016.</p>\r\n', 'fängelse, barn, bebisar, 668', '1', 'https://stockholmcf.org/turkish-govt-jails-108-babies-and-children-more-in-past-3-months-bringing-total-to-668/'),
(8, '2017-11-14 14:55:41', 'img/icerik/22865218312595820345bebek1-696x398.jpg', '668 young children to welcome Eid al-Adha in Turkish prisons', '<p>Six hundred sixty-eight children under the age of 6 will welcome the Muslim festival of Eid al-Adha (Kurban Bayramı) on Friday in jails across Turkey where they are staying with their mothers, TR724 reported on Thursday.</p>\r\n\r\n<p>According to TR724, at least 108 more children, mostly infants, toddlers and newborn babies, had joined others in prisons in the last three months, bringing the total number to 668, as part of a government crackdown on the G&uuml;len movement following a failed coup last year for which the government blames the movement. The movement denies all accusations.</p>\r\n\r\n<p>There are 149 infants younger than 12 months in prisons, the report said.</p>\r\n\r\n<p>On Aug. 11, BBC Turkish service reported that&nbsp;hundreds of women are in pretrial detention in jails across Turkey with their infants, some of them less than six months old, due to a state of emergency declared after the failed coup.</p>\r\n', 'prison, fängelse, barn, bebsiar, 668', '1', 'https://www.turkishminute.com/2017/08/31/video-668-young-children-to-welcome-eid-al-adha-in-turkish-prisons/');

--
-- Dökümü yapılmış tablolar için indeksler
--

--
-- Tablo için indeksler `icerik`
--
ALTER TABLE `icerik`
  ADD PRIMARY KEY (`icerik_id`);

--
-- Dökümü yapılmış tablolar için AUTO_INCREMENT değeri
--

--
-- Tablo için AUTO_INCREMENT değeri `icerik`
--
ALTER TABLE `icerik`
  MODIFY `icerik_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
