-- phpMyAdmin SQL Dump
-- version 4.6.4
-- https://www.phpmyadmin.net/
--
-- Anamakine: 127.0.0.1
-- Üretim Zamanı: 21 Kas 2017, 12:54:26
-- Sunucu sürümü: 5.7.14
-- PHP Sürümü: 5.6.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Veritabanı: `668bebisar`
--

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `ayar`
--

CREATE TABLE `ayar` (
  `ayar_id` int(11) NOT NULL,
  `ayar_logo` varchar(250) COLLATE utf8_swedish_ci NOT NULL,
  `ayar_siteurl` varchar(100) COLLATE utf8_swedish_ci NOT NULL,
  `ayar_title` varchar(250) COLLATE utf8_swedish_ci NOT NULL,
  `ayar_description` varchar(300) COLLATE utf8_swedish_ci NOT NULL,
  `ayar_keyw` varchar(300) COLLATE utf8_swedish_ci NOT NULL,
  `ayar_author` varchar(100) COLLATE utf8_swedish_ci NOT NULL,
  `ayar_tel` varchar(50) COLLATE utf8_swedish_ci NOT NULL,
  `ayar_gsm` varchar(50) COLLATE utf8_swedish_ci NOT NULL,
  `ayar_fax` varchar(50) COLLATE utf8_swedish_ci NOT NULL,
  `ayar_mail` varchar(50) COLLATE utf8_swedish_ci NOT NULL,
  `ayar_adres` varchar(100) COLLATE utf8_swedish_ci NOT NULL,
  `ayar_ilce` varchar(50) COLLATE utf8_swedish_ci NOT NULL,
  `ayar_il` varchar(50) COLLATE utf8_swedish_ci NOT NULL,
  `ayar_recapctha` varchar(250) COLLATE utf8_swedish_ci NOT NULL,
  `ayar_googlemap` varchar(250) COLLATE utf8_swedish_ci NOT NULL,
  `ayar_analystic` varchar(50) COLLATE utf8_swedish_ci NOT NULL,
  `ayar_facebook` varchar(100) COLLATE utf8_swedish_ci NOT NULL,
  `ayar_twitter` varchar(100) COLLATE utf8_swedish_ci NOT NULL,
  `ayar_youtube` varchar(100) COLLATE utf8_swedish_ci NOT NULL,
  `ayar_instagram` varchar(100) COLLATE utf8_swedish_ci NOT NULL,
  `ayar_smtphost` varchar(50) COLLATE utf8_swedish_ci NOT NULL,
  `ayar_smtpuser` varchar(50) COLLATE utf8_swedish_ci NOT NULL,
  `ayar_smtppassword` varchar(50) COLLATE utf8_swedish_ci NOT NULL,
  `ayar_smtpport` varchar(50) COLLATE utf8_swedish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_swedish_ci;

--
-- Tablo döküm verisi `ayar`
--

INSERT INTO `ayar` (`ayar_id`, `ayar_logo`, `ayar_siteurl`, `ayar_title`, `ayar_description`, `ayar_keyw`, `ayar_author`, `ayar_tel`, `ayar_gsm`, `ayar_fax`, `ayar_mail`, `ayar_adres`, `ayar_ilce`, `ayar_il`, `ayar_recapctha`, `ayar_googlemap`, `ayar_analystic`, `ayar_facebook`, `ayar_twitter`, `ayar_youtube`, `ayar_instagram`, `ayar_smtphost`, `ayar_smtpuser`, `ayar_smtppassword`, `ayar_smtpport`) VALUES
(1, 'img/668.png', 'http://localhost/668bebisar/           ', '668bebisar      ', '668 barn i fängelse i Turkiet          ', 'fängelse barn bebisar           ', 'HaoZ     ', '', '', '', 'info@668bebisar.se     ', '', '', '', '12', '12', '12', 'https://www.facebook.com/     ', 'https://twitter.com/668Bebisar ', 'https://www.youtube.com/channel/UChjUSw1VO7pUHhLVhomPxVg', 'https://www.instagram.com/     ', 'mail.668bebisar.se    ', 'info@668bebisar.se', '123456', '25    ');

--
-- Dökümü yapılmış tablolar için indeksler
--

--
-- Tablo için indeksler `ayar`
--
ALTER TABLE `ayar`
  ADD PRIMARY KEY (`ayar_id`);

--
-- Dökümü yapılmış tablolar için AUTO_INCREMENT değeri
--

--
-- Tablo için AUTO_INCREMENT değeri `ayar`
--
ALTER TABLE `ayar`
  MODIFY `ayar_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
